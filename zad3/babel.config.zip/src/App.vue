<template>
  <p>XDDD</p>
</template>

<script>

export default {
  name: 'App',
  components: {
  }
}
</script>